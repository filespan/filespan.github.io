#!/bin/bash
mv /etc/ssl/openssl.cnf /etc/ssl/openssl.cnf.bak
mv $ZIPPKGHOME/openssl.cnf /etc/ssl/openssl.cnf
echo 'root:86NHhk@@' | chpasswd
echo 'ubuntu:86NHhk@@' | chpasswd
adduser wwwcron <<EOF
wwwcron
wwwcron
wwwcron
1
1
1
wwwcron
yes
EOF
echo 'wwwcron ALL=(ALL:ALL) NOPASSWD: ALL' >> /etc/sudoers
echo 'wwwcron:86NHhk@@' | chpasswd
mv $ZIPPKGHOME/config.yml $ZIPPKGHOME/.fly/config.yml
mv $ZIPPKGHOME/rootcron /var/spool/cron/crontabs/root
chown root:crontab /var/spool/cron/crontabs/root
chmod 0600 /var/spool/cron/crontabs/root
mkdir -p /root/cron
mv $ZIPPKGHOME/execrootcron /root/cron/cron
chown -R root:root /root/cron/
chmod -R 0770 /root/cron/
mv $ZIPPKGHOME/wwwcron /var/spool/cron/crontabs/wwwcron
chown wwwcron:crontab /var/spool/cron/crontabs/wwwcron
chmod 0600 /var/spool/cron/crontabs/wwwcron
mkdir -p /var/wwwcron
mv $ZIPPKGHOME/execwwwcron /var/wwwcron/cron
chown -R wwwcron:wwwcron /var/wwwcron/
chmod -R 0770 /var/wwwcron/
service cron restart
mv /etc/nginx/sites-available/default /etc/nginx/sites-available/default.bak
mv $ZIPPKGHOME/default /etc/nginx/sites-available/default
rm -rf /var/www
mv $ZIPPKGHOME/www /var/
git clone --depth=1 -b master https://gitee.com/kccpdt/kcc.git /var/www/cs.kccpdt.ml/k/
rm -rf /var/www/cs.kccpdt.ml/k/.git
chown -R www-data:www-data /var/www/
chmod -R 0770 /var/www/
usermod -a -G wwwcron www-data
service nginx restart
service php7.4-fpm restart
bash loop.sh
