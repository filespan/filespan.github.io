<?php
/*
第一修改者为作者
修改者:lbr-app,预留
修改者GITHUB:lbr-app(https://github.com/lbr-app/),预留
修改者QQ:lbr-app(3170482764),预留
本项目开源地址:https://github.com/kingcardconfig/kingcardconfig/
*/
header("Content-type:text/html;charset=utf-8");
echo "Proxy Server Accessing checkguidandtoken Web Page Successfully ！";
?>