<?php
/*
第一修改者为作者
修改者:lbr-dev,预留
修改者GITHUB:lbr-dev(https://github.com/lbr-dev/),预留
修改者QQ:lbr-dev(3170482764),预留
本项目开源地址:https://github.com/kingcardconfig/kingcardconfig/
*/
error_reporting(E_ERROR|E_WARNING|E_PARSE);
date_default_timezone_set('Asia/Shanghai');
header("Content-type:text/html;charset=utf-8");
$url = $_GET['url'];
$c=file_get_contents($url);
$explode=explode(',',$c);
$guid = $explode[0];
$token = $explode[1];
$time=date("Y-m-d H:i:s");
$wkdtconfig='{"Time":"'.$time.'","Guid":"'.$guid.'","Token":"'.$token.'"}';
echo $wkdtconfig;
?>