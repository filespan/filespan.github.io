<?php
/*
第一修改者为作者
修改者:lbr-dev,预留
修改者GITHUB:lbr-dev(https://github.com/lbr-dev/),预留
修改者QQ:lbr-dev(3170482764),预留
本项目开源地址:https://github.com/kingcardconfig/kingcardconfig/
*/
error_reporting(E_ERROR|E_WARNING|E_PARSE);
date_default_timezone_set('Asia/Shanghai');
header("Content-type:text/html;charset=utf-8");
$kcchost = $_GET['kcchost'];
$response["kccversionnumber"] = "100220210530232500";
$response["kcczipurl"] = "https://filespan.kccpdt.ml/kcc.zip";
$response["kcchost"] = $kcchost;
echo json_encode($response);
?>