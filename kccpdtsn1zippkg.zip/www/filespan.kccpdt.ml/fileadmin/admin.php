<?php
define("U","admin");
define("P","86NHhk@@");
?>