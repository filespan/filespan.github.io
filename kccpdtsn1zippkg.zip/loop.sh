#!/bin/bash
for ((;;))
do
apt update
apt dist-upgrade -y
apt autoremove -y
sleep 86400
done
